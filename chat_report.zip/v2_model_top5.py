import torch
import torch.nn as nn
import torch.nn.functional as F

class OscillatorA(nn.Module):
    """
    Block-diagonal A with M oscillators, K=2M.
    Each block: rho * rotation(omega).
    """
    def __init__(self, M: int):
        super().__init__()
        self.M = M
        self.omega_raw = nn.Parameter(torch.zeros(M))
        self.rho_raw   = nn.Parameter(torch.zeros(M))

    def forward(self):
        omega = torch.sigmoid(self.omega_raw) * torch.pi  # (0, pi)
        rho   = torch.sigmoid(self.rho_raw)               # (0, 1)

        K = 2 * self.M
        A = torch.zeros((K, K), device=omega.device, dtype=omega.dtype)
        for m in range(self.M):
            c = torch.cos(omega[m])
            s = torch.sin(omega[m])
            B = rho[m] * torch.stack([
                torch.stack([ c, -s]),
                torch.stack([ s,  c]),
            ])  # [2,2]
            A[2*m:2*m+2, 2*m:2*m+2] = B
        return A

class Top5OscillatorForecaster(nn.Module):
    def __init__(self, T: int, N: int, K: int = 4):
        super().__init__()
        assert K % 2 == 0
        self.T, self.N, self.K = T, N, K

        # Trainable latent trajectory over the whole observed sequence
        self.Z = nn.Parameter(torch.randn(T, K) * 0.1)

        # Component loadings
        self.W = nn.Parameter(torch.randn(N, K) * 0.1)

        # Global persistence a >= 0
        self.a_raw = nn.Parameter(torch.tensor(0.0))

        # Oscillatory dynamics A
        self.A_builder = OscillatorA(K // 2)

    def scores_for_time(self, t: int, Y_prev: torch.Tensor):
        """
        Scores for predicting Y[t], given Z[t] and Y[t-1].
        """
        a = F.softplus(self.a_raw)
        return self.W @ self.Z[t] + a * Y_prev

    def dynamics_loss(self):
        """
        Penalize Z_{t+1} - A Z_t
        """
        A = self.A_builder()
        pred = self.Z[:-1] @ A.T
        err = self.Z[1:] - pred
        return err.pow(2).sum(dim=1).mean()

def ranking_loss(scores, pos_idx, neg_idx):
    """
    Pairwise logistic ranking loss with negative sampling.
    """
    pos_scores = scores[pos_idx]          # [P]
    neg_scores = scores[neg_idx]          # [Q]
    diff = pos_scores[:, None] - neg_scores[None, :]
    return F.softplus(-diff).mean()

@torch.no_grad()
def forecast_next_top5(model, Y_last_row):
    """
    Forecast step T+1 using:
      Z_{T+1} = A Z_T
      scores = W Z_{T+1} + a * Y_T
      top5(scores)
    """
    A = model.A_builder()
    a = F.softplus(model.a_raw)

    Z_T = model.Z[-1]
    Z_next = A @ Z_T
    scores = model.W @ Z_next + a * Y_last_row
    top5 = torch.topk(scores, k=5).indices
    return top5, scores
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

# -----------------------
# Data loading (growing T)
# -----------------------
def load_Y(path, device="cpu"):
    df = pd.read_csv(path, header=None)
    X = df.to_numpy(dtype=np.float32)
    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}.")
    Y = (X > 0.5).astype(np.float32)

    row_sums = Y.sum(axis=1)
    bad = np.where(row_sums != 5)[0]
    if bad.size > 0:
        i = int(bad[0])
        raise ValueError(f"Row {i} sums to {row_sums[i]} (expected 5).")
    return torch.tensor(Y, device=device)

# -----------------------
# Ranking loss for top-5 prediction
# -----------------------
def ranking_loss(scores, y_true, neg_per_pos=20):
    """
    scores: [N]
    y_true: [N] binary with exactly 5 ones
    """
    pos_idx = torch.where(y_true > 0.5)[0]          # [5]
    neg_candidates = torch.where(y_true < 0.5)[0]   # [45]

    Q = neg_per_pos * pos_idx.numel()
    neg_idx = neg_candidates[torch.randint(0, neg_candidates.numel(), (Q,), device=scores.device)]

    pos_scores = scores[pos_idx]      # [5]
    neg_scores = scores[neg_idx]      # [Q]
    diff = pos_scores[:, None] - neg_scores[None, :]
    return F.softplus(-diff).mean()

# -----------------------
# Model: GRU -> scores for next step -> top5
# -----------------------
class Top5GRU(nn.Module):
    def __init__(self, N=50, hidden=32):
        super().__init__()
        self.N = N
        self.gru = nn.GRU(input_size=N, hidden_size=hidden, batch_first=True)
        self.out = nn.Linear(hidden, N)
        self.a_raw = nn.Parameter(torch.tensor(0.0))  # persistence >= 0

    def forward(self, Y_seq):
        """
        Y_seq: [T, N] or [B, T, N]
        returns scores for each time t based on hidden at t-1:
          scores_next[t] predicts Y[t] using h_{t-1} and persistence from Y[t-1]
        We'll implement training in a loop for clarity.
        """
        raise NotImplementedError

    def step_scores_next(self, h_prev, y_prev):
        a = F.softplus(self.a_raw)
        return self.out(h_prev) + a * y_prev

def train_full_sequence(model, Y, epochs=20, lr=1e-3, neg_per_pos=20, weight_decay=1e-4):
    """
    Train to predict Y[t] from history up to t-1 (one-step-ahead) for all t=1..T-1.
    Y: [T, N]
    """
    T, N = Y.shape
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)

    # GRU expects [B, T, N]
    Y_batch = Y.unsqueeze(0)  # [1, T, N]

    for ep in range(epochs):
        opt.zero_grad()

        # Run GRU over entire sequence
        # out_seq: [1, T, hidden]
        out_seq, _ = model.gru(Y_batch)

        # out_seq[0, t] is h_t
        # Predict Y[t] from h_{t-1} and y_{t-1}
        loss = 0.0
        steps = 0
        for t in range(1, T):
            h_prev = out_seq[0, t-1]     # [hidden]
            y_prev = Y[t-1]              # [N]
            scores = model.step_scores_next(h_prev, y_prev)  # [N]
            loss = loss + ranking_loss(scores, Y[t], neg_per_pos=neg_per_pos)
            steps += 1

        loss = loss / steps
        loss.backward()
        opt.step()

        if (ep + 1) % 5 == 0:
            print(f"epoch={ep+1:3d} loss={loss.item():.4f} a={F.softplus(model.a_raw).item():.3f}")

    return model

@torch.no_grad()
def forecast_next(model, Y):
    """
    One-step ahead forecast for time T (next unseen step), given observed Y[0..T-1].
    Returns top-5 indices.
    """
    Y_batch = Y.unsqueeze(0)  # [1, T, N]
    out_seq, _ = model.gru(Y_batch)
    h_last = out_seq[0, -1]     # h_{T-1}
    y_last = Y[-1]              # Y_{T-1}
    scores = model.step_scores_next(h_last, y_last)
    top5 = torch.topk(scores, k=5).indices
    return top5, scores

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    Y = load_Y("data.csv", device=device).float()

    model = Top5GRU(N=50, hidden=32).to(device)
    model = train_full_sequence(model, Y, epochs=30, lr=1e-3)

    top5, _ = forecast_next(model, Y)
    print("Forecast top-5 indices for next step:", top5.tolist())

if __name__ == "__main__":
    main()
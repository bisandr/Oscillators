import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

def load_Y(path, device="cpu"):
    df = pd.read_csv(path, header=None)
    X = df.to_numpy(dtype=np.float32)
    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}.")
    Y = (X > 0.5).astype(np.float32)

    row_sums = Y.sum(axis=1)
    bad = np.where(row_sums != 5)[0]
    if bad.size > 0:
        i = int(bad[0])
        raise ValueError(f"Row {i} sums to {row_sums[i]} (expected 5).")

    Yt = torch.tensor(Y, device=device)
    if Yt.shape[0] < 2:
        raise ValueError(f"Need at least 2 rows; got T={Yt.shape[0]}.")
    return Yt

def ranking_loss(scores, y_true, neg_per_pos=20):
    pos_idx = torch.where(y_true > 0.5)[0]
    neg_candidates = torch.where(y_true < 0.5)[0]
    Q = neg_per_pos * pos_idx.numel()
    neg_idx = neg_candidates[torch.randint(0, neg_candidates.numel(), (Q,), device=scores.device)]

    pos_scores = scores[pos_idx]
    neg_scores = scores[neg_idx]
    diff = pos_scores[:, None] - neg_scores[None, :]
    return F.softplus(-diff).mean()

class Top5GRU(nn.Module):
    def __init__(self, N=50, hidden=32):
        super().__init__()
        self.gru = nn.GRU(input_size=N, hidden_size=hidden, batch_first=True)
        self.out = nn.Linear(hidden, N)
        self.a_raw = nn.Parameter(torch.tensor(0.0))  # persistence >= 0

    def scores_next(self, h_prev, y_prev):
        a = F.softplus(self.a_raw)
        return self.out(h_prev) + a * y_prev

def train_from_scratch(model, Y, epochs=120, lr=1e-3, neg_per_pos=20, weight_decay=1e-4):
    T, N = Y.shape
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    Y_batch = Y.unsqueeze(0)  # [1, T, 50]

    for ep in range(epochs):
        opt.zero_grad()
        h_seq, _ = model.gru(Y_batch)  # [1, T, hidden]

        loss = 0.0
        steps = 0
        for t in range(1, T):
            h_prev = h_seq[0, t-1]
            scores = model.scores_next(h_prev, Y[t-1])
            loss = loss + ranking_loss(scores, Y[t], neg_per_pos=neg_per_pos)
            steps += 1

        loss = loss / steps
        loss.backward()
        opt.step()

        if (ep + 1) % 20 == 0:
            a_val = F.softplus(model.a_raw).item()
            print(f"epoch={ep+1:3d}/{epochs} loss={loss.item():.4f} a={a_val:.3f}")

    return model

@torch.no_grad()
def forecast_one_step(model, Y):
    Y_batch = Y.unsqueeze(0)
    h_seq, _ = model.gru(Y_batch)
    h_last = h_seq[0, -1]
    scores = model.scores_next(h_last, Y[-1])
    top5 = torch.topk(scores, k=5).indices
    return top5, scores

def main():
    # Deterministic retrains (so week-to-week changes mostly reflect new data)
    np.random.seed(0)
    torch.manual_seed(0)
    torch.use_deterministic_algorithms(False)  # keep default; set True if you want stricter determinism

    device = "cuda" if torch.cuda.is_available() else "cpu"
    Y = load_Y("data.csv", device=device).float()
    T, N = Y.shape
    print(f"Loaded data.csv with T={T}, N={N}")

    model = Top5GRU(N=50, hidden=32).to(device)
    model = train_from_scratch(model, Y, epochs=120, lr=1e-3)

    top5, _ = forecast_one_step(model, Y)
    print("Forecast top-5 (0-based):", top5.tolist())
    print("Forecast top-5 (1-based):", [i + 1 for i in top5.tolist()])

if __name__ == "__main__":
    main()
import torch
from top5_oscillator_forecaster import Top5OscillatorForecaster, ranking_loss

def train_model(Y, K=4, neg_per_pos=20, epochs=2000, lr=1e-2,
                lambda_dyn=1.0, lambda_w=1e-3, device="cpu"):
    Y = Y.to(device).float()
    T, N = Y.shape

    model = Top5OscillatorForecaster(T=T, N=N, K=K).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    # Precompute pos indices for each t
    pos_list = [torch.where(Y[t] > 0.5)[0] for t in range(T)]

    for ep in range(epochs):
        opt.zero_grad()

        loss_rank = 0.0
        steps = 0

        for t in range(1, T):
            scores = model.scores_for_time(t, Y_prev=Y[t-1])

            pos_idx = pos_list[t]  # should be length 5
            # sample negatives from the 45 zeros
            neg_candidates = torch.where(Y[t] < 0.5)[0]
            # sample Q = neg_per_pos * P negatives (with replacement is fine)
            Q = neg_per_pos * pos_idx.numel()
            neg_idx = neg_candidates[torch.randint(0, neg_candidates.numel(), (Q,), device=device)]

            loss_rank = loss_rank + ranking_loss(scores, pos_idx, neg_idx)
            steps += 1

        loss_rank = loss_rank / steps
        loss_dyn = model.dynamics_loss()
        loss_w = (model.W.pow(2)).mean()

        loss = loss_rank + lambda_dyn * loss_dyn + lambda_w * loss_w
        loss.backward()
        opt.step()

        if (ep + 1) % 200 == 0:
            print(f"ep={ep+1} loss={loss.item():.4f} rank={loss_rank.item():.4f} dyn={loss_dyn.item():.4f}")

    return model
import torch
from model_top5 import Top5OscillatorForecaster, ranking_loss

@torch.no_grad()
def hit_at_5_full(model, Y):
    """
    Evaluate one-step-ahead Hit@5 over the observed sequence:
    predict t from t-1 for t=1..T-1.
    """
    Y = Y.float()
    T, N = Y.shape
    hits = []
    for t in range(1, T):
        scores = model.scores_for_time(t, Y_prev=Y[t-1])
        pred = torch.topk(scores, k=5).indices
        true = torch.where(Y[t] > 0.5)[0]
        hits.append(len(set(pred.tolist()) & set(true.tolist())))
    return sum(hits) / len(hits)

def train_on_full_sequence(
    Y,
    K=4,
    neg_per_pos=20,
    epochs=2000,
    lr=1e-2,
    lambda_dyn=1.0,
    lambda_w=1e-3,
    device="cpu",
):
    Y = Y.to(device).float()
    T, N = Y.shape

    model = Top5OscillatorForecaster(T=T, N=N, K=K).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    pos_list = [torch.where(Y[t] > 0.5)[0] for t in range(T)]
    neg_list = [torch.where(Y[t] < 0.5)[0] for t in range(T)]

    for ep in range(epochs):
        opt.zero_grad()

        loss_rank = 0.0
        steps = 0

        for t in range(1, T):
            scores = model.scores_for_time(t, Y_prev=Y[t-1])
            pos_idx = pos_list[t]               # length 5
            neg_candidates = neg_list[t]        # length 45

            Q = neg_per_pos * pos_idx.numel()
            neg_idx = neg_candidates[torch.randint(
                0, neg_candidates.numel(), (Q,), device=device
            )]

            loss_rank = loss_rank + ranking_loss(scores, pos_idx, neg_idx)
            steps += 1

        loss_rank = loss_rank / steps
        loss_dyn = model.dynamics_loss()
        loss_w = model.W.pow(2).mean()

        loss = loss_rank + lambda_dyn * loss_dyn + lambda_w * loss_w
        loss.backward()
        opt.step()

        if (ep + 1) % 200 == 0:
            hit5 = hit_at_5_full(model, Y)
            print(
                f"ep={ep+1:4d} loss={loss.item():.4f} "
                f"rank={loss_rank.item():.4f} dyn={loss_dyn.item():.4f} "
                f"hit5={hit5:.3f}"
            )

    return model
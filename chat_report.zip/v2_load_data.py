import pandas as pd
import numpy as np
import torch

def load_Y_from_csv(path: str, device="cpu"):
    # No header in your file
    df = pd.read_csv(path, header=None)

    X = df.to_numpy(dtype=np.float32)

    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}.")

    # Convert to strict binary (in case of floats)
    Y = (X > 0.5).astype(np.float32)

    # Sanity: each row must sum to 5
    row_sums = Y.sum(axis=1)
    bad = np.where(row_sums != 5)[0]
    if bad.size > 0:
        # show a few offending rows and their sums
        preview = [(int(i), float(row_sums[i])) for i in bad[:10]]
        raise ValueError(
            f"Row sum check failed: expected exactly 5 ones per row, "
            f"but found sums {np.unique(row_sums)}. Examples (row, sum): {preview}"
        )

    return torch.tensor(Y, device=device)
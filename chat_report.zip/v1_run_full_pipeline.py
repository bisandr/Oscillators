import torch
from load_data import load_Y_from_csv
from train_full import train_on_full_sequence
from model_top5 import forecast_next_top5

device = "cuda" if torch.cuda.is_available() else "cpu"

Y = load_Y_from_csv("data.csv", device=device)  # [400, 50]

model = train_on_full_sequence(
    Y,
    K=4,
    neg_per_pos=20,
    epochs=2000,
    lr=1e-2,
    lambda_dyn=1.0,
    lambda_w=1e-3,
    device=device
)

top5, scores = forecast_next_top5(model, Y_last_row=Y[-1])
print("Forecast for step 401 (top-5 component indices):", top5.tolist())
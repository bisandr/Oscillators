import pandas as pd
import numpy as np
import torch

def load_Y_from_csv(path, device="cpu"):
    df = pd.read_csv(path)

    # If there is a time column, drop it:
    # df = df.drop(columns=["time"])  # uncomment if needed

    X = df.to_numpy(dtype=np.float32)

    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}. If you have an index/time column, drop it.")

    # Convert to binary if it's 0/1-ish
    Y = (X > 0.5).astype(np.float32)

    # Sanity checks
    row_sums = Y.sum(axis=1)
    if not np.all(row_sums == 5):
        bad = np.where(row_sums != 5)[0][:10]
        raise ValueError(
            f"Row sum check failed: expected exactly 5 ones per row. "
            f"Found {np.unique(row_sums)}. First bad rows: {bad}."
        )

    return torch.tensor(Y, device=device)
import torch
from load_data import load_Y_from_csv
from train_eval import train_time_split
from model_top5 import predict_next_top5

device = "cuda" if torch.cuda.is_available() else "cpu"

Y = load_Y_from_csv("your_data.csv", device=device)   # shape [400, 50]

model = train_time_split(
    Y,
    K=4,
    T_train=300,
    neg_per_pos=20,
    epochs=2000,
    lr=1e-2,
    lambda_dyn=1.0,
    lambda_w=1e-3,
    device=device
)

top5_idx, scores = predict_next_top5(model, Y_last_row=Y[-1])
print("Predicted next-step top-5 component indices:", top5_idx.tolist())
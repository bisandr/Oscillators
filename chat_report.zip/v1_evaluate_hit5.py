import torch

@torch.no_grad()
def hit_at_5(model, Y):
    Y = Y.float()
    T, N = Y.shape
    hits = []
    for t in range(1, T):
        scores = model.scores_for_time(t, Y_prev=Y[t-1])
        pred = torch.topk(scores, k=5).indices
        true = torch.where(Y[t] > 0.5)[0]
        hit = len(set(pred.cpu().tolist()) & set(true.cpu().tolist()))
        hits.append(hit)
    return sum(hits)/len(hits), hits
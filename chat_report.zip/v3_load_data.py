import pandas as pd
import numpy as np
import torch

def load_Y_from_csv(path: str, device="cpu"):
    # Your file: no header, no index column
    df = pd.read_csv(path, header=None)
    X = df.to_numpy(dtype=np.float32)

    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}.")

    Y = (X > 0.5).astype(np.float32)

    row_sums = Y.sum(axis=1)
    bad = np.where(row_sums != 5)[0]
    if bad.size > 0:
        preview = [(int(i), float(row_sums[i])) for i in bad[:10]]
        raise ValueError(
            f"Row sum check failed: expected exactly 5 ones per row; "
            f"found sums {np.unique(row_sums)}. Examples (row, sum): {preview}"
        )

    return torch.tensor(Y, device=device)
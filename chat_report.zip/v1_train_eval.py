import torch
from model_top5 import Top5OscillatorForecaster, ranking_loss

@torch.no_grad()
def hit_at_5_on_range(model, Y, t_start, t_end):
    # evaluates predictions for t in [t_start, t_end], using Y[t-1] as input
    hits = []
    for t in range(t_start, t_end + 1):
        scores = model.scores_for_time(t, Y_prev=Y[t-1])
        pred = torch.topk(scores, k=5).indices
        true = torch.where(Y[t] > 0.5)[0]
        hits.append(len(set(pred.tolist()) & set(true.tolist())))
    return sum(hits) / len(hits)

def train_time_split(Y, K=4, T_train=300, neg_per_pos=20, epochs=2000, lr=1e-2,
                     lambda_dyn=1.0, lambda_w=1e-3, device="cpu"):
    Y = Y.to(device).float()
    T, N = Y.shape
    assert T_train < T

    model = Top5OscillatorForecaster(T=T, N=N, K=K).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    pos_list = [torch.where(Y[t] > 0.5)[0] for t in range(T)]

    # Train predicts t=1..T_train-1 (so that both t and t-1 are inside train block)
    train_t0, train_t1 = 1, T_train - 1
    # Val predicts t=T_train..T-1 (t-1 is available)
    val_t0, val_t1 = T_train, T - 1

    for ep in range(epochs):
        opt.zero_grad()

        loss_rank = 0.0
        steps = 0

        for t in range(train_t0, train_t1 + 1):
            scores = model.scores_for_time(t, Y_prev=Y[t-1])
            pos_idx = pos_list[t]

            neg_candidates = torch.where(Y[t] < 0.5)[0]
            Q = neg_per_pos * pos_idx.numel()
            neg_idx = neg_candidates[torch.randint(0, neg_candidates.numel(), (Q,), device=device)]

            loss_rank = loss_rank + ranking_loss(scores, pos_idx, neg_idx)
            steps += 1

        loss_rank = loss_rank / steps
        loss_dyn = model.dynamics_loss()
        loss_w = model.W.pow(2).mean()
        loss = loss_rank + lambda_dyn * loss_dyn + lambda_w * loss_w

        loss.backward()
        opt.step()

        if (ep + 1) % 200 == 0:
            train_hit = hit_at_5_on_range(model, Y, train_t0, train_t1)
            val_hit = hit_at_5_on_range(model, Y, val_t0, val_t1)
            print(f"ep={ep+1:4d} loss={loss.item():.4f} "
                  f"rank={loss_rank.item():.4f} dyn={loss_dyn.item():.4f} "
                  f"hit5_train={train_hit:.3f} hit5_val={val_hit:.3f}")

    return model
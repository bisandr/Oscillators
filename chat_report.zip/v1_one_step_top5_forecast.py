import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

# -----------------------
# Load data (no header)
# -----------------------
def load_Y(path, device="cpu"):
    df = pd.read_csv(path, header=None)
    X = df.to_numpy(dtype=np.float32)
    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}.")
    Y = (X > 0.5).astype(np.float32)

    row_sums = Y.sum(axis=1)
    if not np.all(row_sums == 5):
        bad = np.where(row_sums != 5)[0][:10]
        raise ValueError(f"Expected exactly 5 ones per row. Bad rows (first 10): {bad.tolist()} "
                         f"with sums {row_sums[bad].tolist()}")
    return torch.tensor(Y, device=device)

# -----------------------
# Model
# -----------------------
class OscillatorA(nn.Module):
    # K = 2M
    def __init__(self, M: int):
        super().__init__()
        self.M = M
        self.omega_raw = nn.Parameter(torch.zeros(M))
        self.rho_raw   = nn.Parameter(torch.zeros(M))

    def forward(self):
        omega = torch.sigmoid(self.omega_raw) * torch.pi  # (0, pi)
        rho   = torch.sigmoid(self.rho_raw)               # (0, 1)
        K = 2 * self.M
        A = torch.zeros((K, K), device=omega.device, dtype=omega.dtype)
        for m in range(self.M):
            c = torch.cos(omega[m])
            s = torch.sin(omega[m])
            B = rho[m] * torch.stack([
                torch.stack([ c, -s]),
                torch.stack([ s,  c]),
            ])
            A[2*m:2*m+2, 2*m:2*m+2] = B
        return A

class Top5OneStepModel(nn.Module):
    def __init__(self, T: int, N: int, K: int = 4):
        super().__init__()
        assert K % 2 == 0
        self.T, self.N, self.K = T, N, K
        self.Z = nn.Parameter(torch.randn(T, K) * 0.1)     # latent per observed time step
        self.W = nn.Parameter(torch.randn(N, K) * 0.1)     # component loadings
        self.a_raw = nn.Parameter(torch.tensor(0.0))       # persistence >= 0
        self.A_builder = OscillatorA(K // 2)

    def scores_t(self, t: int, y_prev: torch.Tensor):
        a = F.softplus(self.a_raw)
        return self.W @ self.Z[t] + a * y_prev

    def dyn_loss(self):
        A = self.A_builder()
        pred = self.Z[:-1] @ A.T
        err = self.Z[1:] - pred
        return err.pow(2).sum(dim=1).mean()

def ranking_loss(scores, pos_idx, neg_idx):
    pos = scores[pos_idx]             # [5]
    neg = scores[neg_idx]             # [Q]
    diff = pos[:, None] - neg[None, :]
    return F.softplus(-diff).mean()

@torch.no_grad()
def forecast_step_401(model: Top5OneStepModel, Y: torch.Tensor):
    """
    One-step forecast:
      Z_401 = A Z_400
      scores = W Z_401 + a * Y_400
      predict top-5(scores)
    """
    A = model.A_builder()
    a = F.softplus(model.a_raw)
    Z400 = model.Z[-1]
    Z401 = A @ Z400
    scores = model.W @ Z401 + a * Y[-1]
    top5 = torch.topk(scores, k=5).indices
    return top5, scores

# -----------------------
# Train on full sequence
# -----------------------
def train_full(Y, K=4, neg_per_pos=20, epochs=2000, lr=1e-2, lambda_dyn=1.0, lambda_w=1e-3):
    Y = Y.float()
    T, N = Y.shape
    model = Top5OneStepModel(T=T, N=N, K=K).to(Y.device)
    opt = torch.optim.Adam(model.parameters(), lr=lr)

    pos_list = [torch.where(Y[t] > 0.5)[0] for t in range(T)]
    neg_list = [torch.where(Y[t] < 0.5)[0] for t in range(T)]

    for ep in range(epochs):
        opt.zero_grad()
        loss_rank = 0.0
        steps = 0

        for t in range(1, T):  # predict Y[t] from Y[t-1]
            scores = model.scores_t(t, Y[t-1])
            pos_idx = pos_list[t]
            neg_candidates = neg_list[t]
            Q = neg_per_pos * pos_idx.numel()
            neg_idx = neg_candidates[torch.randint(0, neg_candidates.numel(), (Q,), device=Y.device)]
            loss_rank = loss_rank + ranking_loss(scores, pos_idx, neg_idx)
            steps += 1

        loss_rank = loss_rank / steps
        loss_dyn = model.dyn_loss()
        loss_w = model.W.pow(2).mean()
        loss = loss_rank + lambda_dyn * loss_dyn + lambda_w * loss_w
        loss.backward()
        opt.step()

        if (ep + 1) % 200 == 0:
            print(f"ep={ep+1:4d} loss={loss.item():.4f} rank={loss_rank.item():.4f} dyn={loss_dyn.item():.4f}")

    return model

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    Y = load_Y("data.csv", device=device)  # [400, 50]
    model = train_full(Y, K=4, epochs=2000)

    top5, _ = forecast_step_401(model, Y)
    print("Predicted top-5 indices for step 401:", top5.tolist())

if __name__ == "__main__":
    main()
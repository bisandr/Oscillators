import torch
import torch.nn as nn
import torch.nn.functional as F

class OscillatorA(nn.Module):
    def __init__(self, M: int):
        super().__init__()
        self.M = M
        self.omega_raw = nn.Parameter(torch.zeros(M))
        self.rho_raw   = nn.Parameter(torch.zeros(M))

    def forward(self):
        M = self.M
        omega = torch.sigmoid(self.omega_raw) * torch.pi  # (0, pi)
        rho   = torch.sigmoid(self.rho_raw)               # (0, 1)

        A = torch.zeros((2*M, 2*M), device=omega.device, dtype=omega.dtype)
        for m in range(M):
            c = torch.cos(omega[m])
            s = torch.sin(omega[m])
            B = rho[m] * torch.stack([
                torch.stack([ c, -s]),
                torch.stack([ s,  c]),
            ])
            A[2*m:2*m+2, 2*m:2*m+2] = B
        return A

class Top5OscillatorForecaster(nn.Module):
    def __init__(self, T: int, N: int, K: int = 4):
        super().__init__()
        assert K % 2 == 0
        self.T, self.N, self.K = T, N, K
        self.Z = nn.Parameter(torch.randn(T, K) * 0.1)      # latent per t
        self.W = nn.Parameter(torch.randn(N, K) * 0.1)      # loadings per i
        self.a_raw = nn.Parameter(torch.tensor(0.0))        # persistence >=0
        self.A_builder = OscillatorA(K // 2)

    def scores_for_time(self, t: int, Y_prev: torch.Tensor):
        a = F.softplus(self.a_raw)
        scores = self.W @ self.Z[t] + a * Y_prev
        return scores

    def dynamics_loss(self):
        A = self.A_builder()
        pred = self.Z[:-1] @ A.T
        err = self.Z[1:] - pred
        return err.pow(2).sum(dim=1).mean()

def ranking_loss(scores, pos_idx, neg_idx):
    pos_scores = scores[pos_idx]   # [P]
    neg_scores = scores[neg_idx]   # [Q]
    diff = pos_scores[:, None] - neg_scores[None, :]
    return F.softplus(-diff).mean()

@torch.no_grad()
def predict_next_top5(model, Y_last_row):
    """
    Predict top-5 for t = T+1 using Z_T and A (one-step).
    Uses persistence from the last observed row.
    """
    A = model.A_builder()
    a = F.softplus(model.a_raw)

    ZT = model.Z[-1]
    Z_next = A @ ZT
    scores = model.W @ Z_next + a * Y_last_row
    return torch.topk(scores, k=5).indices, scores
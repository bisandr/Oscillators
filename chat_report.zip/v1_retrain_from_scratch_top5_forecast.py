import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F

# -----------------------
# Load growing CSV (no header)
# -----------------------
def load_Y(path, device="cpu"):
    df = pd.read_csv(path, header=None)
    X = df.to_numpy(dtype=np.float32)

    if X.shape[1] != 50:
        raise ValueError(f"Expected 50 columns, got {X.shape[1]}.")

    Y = (X > 0.5).astype(np.float32)

    row_sums = Y.sum(axis=1)
    bad = np.where(row_sums != 5)[0]
    if bad.size > 0:
        i = int(bad[0])
        raise ValueError(f"Row {i} sums to {row_sums[i]} (expected 5).")

    Yt = torch.tensor(Y, device=device)
    if Yt.shape[0] < 2:
        raise ValueError(f"Need at least 2 rows to do one-step training; got T={Yt.shape[0]}.")
    return Yt

# -----------------------
# Ranking loss (one-step top-5)
# -----------------------
def ranking_loss(scores, y_true, neg_per_pos=20):
    pos_idx = torch.where(y_true > 0.5)[0]          # 5
    neg_candidates = torch.where(y_true < 0.5)[0]   # 45

    Q = neg_per_pos * pos_idx.numel()
    neg_idx = neg_candidates[torch.randint(0, neg_candidates.numel(), (Q,), device=scores.device)]

    pos_scores = scores[pos_idx]
    neg_scores = scores[neg_idx]
    diff = pos_scores[:, None] - neg_scores[None, :]
    return F.softplus(-diff).mean()

# -----------------------
# GRU forecaster
# -----------------------
class Top5GRU(nn.Module):
    def __init__(self, N=50, hidden=32):
        super().__init__()
        self.N = N
        self.gru = nn.GRU(input_size=N, hidden_size=hidden, batch_first=True)
        self.out = nn.Linear(hidden, N)
        self.a_raw = nn.Parameter(torch.tensor(0.0))  # persistence >= 0

    def scores_next(self, h_prev, y_prev):
        a = F.softplus(self.a_raw)
        return self.out(h_prev) + a * y_prev

def train_from_scratch(model, Y, epochs, lr=1e-3, neg_per_pos=20, weight_decay=1e-4):
    """
    Train one-step ahead on the whole sequence: predict Y[t] from history up to t-1.
    Y: [T, 50]
    """
    T, N = Y.shape
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=weight_decay)
    Y_batch = Y.unsqueeze(0)  # [1, T, N]

    for ep in range(epochs):
        opt.zero_grad()
        h_seq, _ = model.gru(Y_batch)  # [1, T, hidden]

        loss = 0.0
        steps = 0
        for t in range(1, T):
            h_prev = h_seq[0, t-1]     # hidden at time t-1
            y_prev = Y[t-1]
            scores = model.scores_next(h_prev, y_prev)
            loss = loss + ranking_loss(scores, Y[t], neg_per_pos=neg_per_pos)
            steps += 1

        loss = loss / steps
        loss.backward()
        opt.step()

        if (ep + 1) % max(1, epochs // 5) == 0:
            print(f"epoch={ep+1:4d}/{epochs} loss={loss.item():.4f} a={F.softplus(model.a_raw).item():.3f}")

    return model

@torch.no_grad()
def forecast_one_step(model, Y):
    """
    Forecast next step (T+1) top-5 indices given Y[0..T-1].
    """
    Y_batch = Y.unsqueeze(0)      # [1, T, 50]
    h_seq, _ = model.gru(Y_batch)
    h_last = h_seq[0, -1]         # hidden at last observed step
    y_last = Y[-1]
    scores = model.scores_next(h_last, y_last)
    top5 = torch.topk(scores, k=5).indices
    return top5, scores

def choose_epochs(T):
    """
    Heuristic: as T grows, you usually need fewer epochs to see enough batches.
    Feel free to adjust.
    """
    if T < 300:
        return 60
    if T < 1000:
        return 40
    return 25

def main():
    device = "cuda" if torch.cuda.is_available() else "cpu"
    Y = load_Y("data.csv", device=device).float()
    T, N = Y.shape
    print(f"Loaded Y with shape {Y.shape} (T steps, N components)")

    # Retrain from scratch each run
    model = Top5GRU(N=50, hidden=32).to(device)

    epochs = choose_epochs(T)
    model = train_from_scratch(model, Y, epochs=epochs, lr=1e-3)

    top5, _ = forecast_one_step(model, Y)
    print("One-step forecast top-5 indices for next step:", top5.tolist())

if __name__ == "__main__":
    main()
import torch
import torch.nn as nn
import torch.nn.functional as F

class OscillatorA(nn.Module):
    """
    Builds a block-diagonal A matrix with M oscillators (K = 2*M).
    Each block is rho * rotation(omega).
    """
    def __init__(self, M: int):
        super().__init__()
        self.M = M
        # unconstrained params; we'll transform to valid ranges
        self.omega_raw = nn.Parameter(torch.zeros(M))  # frequency
        self.rho_raw   = nn.Parameter(torch.zeros(M))  # damping

    def forward(self):
        M = self.M
        # omega in (0, pi) (you can widen if you want)
        omega = torch.sigmoid(self.omega_raw) * torch.pi
        # rho in (0, 1) for stability
        rho = torch.sigmoid(self.rho_raw)

        blocks = []
        for m in range(M):
            c = torch.cos(omega[m])
            s = torch.sin(omega[m])
            R = torch.stack([
                torch.stack([ c, -s]),
                torch.stack([ s,  c])
            ])  # [2,2]
            blocks.append(rho[m] * R)

        # block diag
        A = torch.zeros((2*M, 2*M), device=omega.device, dtype=omega.dtype)
        for m, B in enumerate(blocks):
            A[2*m:2*m+2, 2*m:2*m+2] = B
        return A

class Top5OscillatorForecaster(nn.Module):
    def __init__(self, T: int, N: int, K: int = 4):
        super().__init__()
        assert K % 2 == 0, "Use even K (2*M oscillators)."
        self.T, self.N, self.K = T, N, K
        M = K // 2

        # Latent trajectory Z[t] (trainable)
        self.Z = nn.Parameter(torch.randn(T, K) * 0.1)

        # Component loadings W[i]
        self.W = nn.Parameter(torch.randn(N, K) * 0.1)

        # persistence scalar a >= 0
        self.a_raw = nn.Parameter(torch.tensor(0.0))

        # oscillator dynamics
        self.A_builder = OscillatorA(M)

    def scores_for_time(self, t: int, Y_prev: torch.Tensor):
        """
        Scores for predicting Y[t] given Z[t] and Y[t-1].
        Y_prev: shape [N]
        """
        a = F.softplus(self.a_raw)  # >= 0
        Zt = self.Z[t]              # [K]
        scores = self.W @ Zt + a * Y_prev  # [N]
        return scores

    def dynamics_loss(self):
        A = self.A_builder()  # [K,K]
        Z = self.Z
        pred = Z[:-1] @ A.T   # (T-1,K) because Z_{t+1} ~ A Z_t
        err = Z[1:] - pred
        return (err.pow(2).sum(dim=1)).mean()

def ranking_loss(scores, pos_idx, neg_idx):
    """
    scores: [N]
    pos_idx: [P] indices of positives (P=5)
    neg_idx: [Q] indices of sampled negatives
    """
    pos_scores = scores[pos_idx]            # [P]
    neg_scores = scores[neg_idx]            # [Q]
    # pairwise differences: pos - neg -> shape [P,Q]
    diff = pos_scores[:, None] - neg_scores[None, :]
    # want diff large => logistic loss on -diff
    return F.softplus(-diff).mean()

@torch.no_grad()
def forecast_top5(model, Y, start_t, horizon=1):
    """
    One-step (or multi-step) best-guess forecasts using learned A and W.
    For h>1, uses closed-loop persistence (uses predicted Y).
    """
    T, N = Y.shape
    A = model.A_builder()
    a = F.softplus(model.a_raw)

    Zt = model.Z[start_t].clone()
    y_prev = Y[start_t].clone()

    preds = []
    for h in range(horizon):
        Zt = A @ Zt
        scores = model.W @ Zt + a * y_prev
        top5 = torch.topk(scores, k=5).indices
        y_hat = torch.zeros(N, device=Y.device)
        y_hat[top5] = 1.0
        preds.append(top5.cpu())
        y_prev = y_hat
    return preds